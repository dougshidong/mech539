function d = dist(z,i,j);

d = sqrt((z(i,1)-z(j,1)).^2+(z(i,2)-z(j,2)).^2);
