function y = splf(x)
global PPX
y = ppval(PPX,x);
